
# HealthAI: Intelligent Healthcare Assistant Using IBM Granite

This is a basic Streamlit app for an intelligent healthcare assistant. It includes:
- 🗣️ Chatbot for basic medical queries
- 🧠 Disease prediction based on symptoms

## How to Run

1. Install requirements: `pip install -r requirements.txt`
2. Run app: `streamlit run app.py`

## Notes
This is a student-level project created by Sravanthi, Swarnandhra College.
