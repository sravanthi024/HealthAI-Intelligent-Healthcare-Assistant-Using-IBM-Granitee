
import streamlit as st

st.set_page_config(page_title="HealthAI", layout="centered")

st.title("🩺 HealthAI: Intelligent Healthcare Assistant")
st.markdown("Welcome to HealthAI! This app helps with basic health queries and symptom-based predictions.")

tab1, tab2 = st.tabs(["🗣️ Chat with AI", "🧠 Disease Prediction"])

# Tab 1: Chatbot (mock responses)
with tab1:
    user_input = st.text_input("Ask a medical question:")
    if st.button("Get Response"):
        if user_input:
            st.success("I'm not a doctor, but based on what you asked, it's best to consult a healthcare professional.")
        else:
            st.warning("Please enter a question.")

# Tab 2: Disease Prediction (simple logic-based mockup)
with tab2:
    st.subheader("Enter your symptoms")
    symptom1 = st.text_input("Symptom 1")
    symptom2 = st.text_input("Symptom 2")
    symptom3 = st.text_input("Symptom 3")
    if st.button("Predict Condition"):
        if "fever" in (symptom1 + symptom2 + symptom3).lower():
            st.info("Possible Condition: Viral Infection
Recommended: Rest, hydration, and consult a doctor.")
        else:
            st.info("Condition unclear. Please consult a healthcare provider for proper diagnosis.")
